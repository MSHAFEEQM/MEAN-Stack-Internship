export interface Skills {

    id:string,
    title:string,
    skills:[{
        title:string,
        image:string
    }]
}
