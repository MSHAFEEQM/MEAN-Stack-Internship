export interface Projects {

    id:string,
    title:string,
    category:string,
    description:string,
    stack:string,
    image:string,
    link:string

}
