import { Component } from '@angular/core';

@Component({
  selector: 'app-new-sample-component',
  standalone: true,
  imports: [],
  templateUrl: './new-sample-component.component.html',
  styleUrl: './new-sample-component.component.css'
})
export class NewSampleComponentComponent {

}
